// GENERATED CODE - DO NOT MODIFY BY HAND

part of 'vehicle_model.dart';

// **************************************************************************
// JsonSerializableGenerator
// **************************************************************************

_$VehicleModelImpl _$$VehicleModelImplFromJson(Map<String, dynamic> json) =>
    _$VehicleModelImpl(
      id: json['id'] as String,
      type: json['type'] as String?,
      brand: json['brand'] as String?,
      engineType: json['engineType'] as String?,
      licensePlate: json['licensePlate'] as String? ?? '',
    );

Map<String, dynamic> _$$VehicleModelImplToJson(_$VehicleModelImpl instance) =>
    <String, dynamic>{
      'id': instance.id,
      'type': instance.type,
      'brand': instance.brand,
      'engineType': instance.engineType,
      'licensePlate': instance.licensePlate,
    };
