// GENERATED CODE - DO NOT MODIFY BY HAND

part of 'auth_session_model.dart';

// **************************************************************************
// JsonSerializableGenerator
// **************************************************************************

_$AuthSessionModelImpl _$$AuthSessionModelImplFromJson(
        Map<String, dynamic> json) =>
    _$AuthSessionModelImpl(
      isAuthenticated: json['isAuthenticated'] as bool,
      userId: json['userId'] as String?,
      onboardingComplete: json['onboardingComplete'] as bool? ?? false,
    );

Map<String, dynamic> _$$AuthSessionModelImplToJson(
        _$AuthSessionModelImpl instance) =>
    <String, dynamic>{
      'isAuthenticated': instance.isAuthenticated,
      'userId': instance.userId,
      'onboardingComplete': instance.onboardingComplete,
    };
