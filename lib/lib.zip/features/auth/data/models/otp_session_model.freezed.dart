// coverage:ignore-file
// GENERATED CODE - DO NOT MODIFY BY HAND
// ignore_for_file: type=lint
// ignore_for_file: unused_element, deprecated_member_use, deprecated_member_use_from_same_package, use_function_type_syntax_for_parameters, unnecessary_const, avoid_init_to_null, invalid_override_different_default_values_named, prefer_expression_function_bodies, annotate_overrides, invalid_annotation_target, unnecessary_question_mark

part of 'otp_session_model.dart';

// **************************************************************************
// FreezedGenerator
// **************************************************************************

T _$identity<T>(T value) => value;

final _privateConstructorUsedError = UnsupportedError(
    'It seems like you constructed your class using `MyClass._()`. This constructor is only meant to be used by freezed and you are not supposed to need it nor use it.\nPlease check the documentation here for more information: https://github.com/rrousselGit/freezed#adding-getters-and-methods-to-our-models');

OtpSessionModel _$OtpSessionModelFromJson(Map<String, dynamic> json) {
  return _OtpSessionModel.fromJson(json);
}

/// @nodoc
mixin _$OtpSessionModel {
  String get identifier => throw _privateConstructorUsedError;
  String get identifierType =>
      throw _privateConstructorUsedError; // 'email' | 'phone'
  String get purpose =>
      throw _privateConstructorUsedError; // 'login' | 'signup'
  String get code => throw _privateConstructorUsedError;
  DateTime get expiresAt => throw _privateConstructorUsedError;

  Map<String, dynamic> toJson() => throw _privateConstructorUsedError;
  @JsonKey(ignore: true)
  $OtpSessionModelCopyWith<OtpSessionModel> get copyWith =>
      throw _privateConstructorUsedError;
}

/// @nodoc
abstract class $OtpSessionModelCopyWith<$Res> {
  factory $OtpSessionModelCopyWith(
          OtpSessionModel value, $Res Function(OtpSessionModel) then) =
      _$OtpSessionModelCopyWithImpl<$Res, OtpSessionModel>;
  @useResult
  $Res call(
      {String identifier,
      String identifierType,
      String purpose,
      String code,
      DateTime expiresAt});
}

/// @nodoc
class _$OtpSessionModelCopyWithImpl<$Res, $Val extends OtpSessionModel>
    implements $OtpSessionModelCopyWith<$Res> {
  _$OtpSessionModelCopyWithImpl(this._value, this._then);

  // ignore: unused_field
  final $Val _value;
  // ignore: unused_field
  final $Res Function($Val) _then;

  @pragma('vm:prefer-inline')
  @override
  $Res call({
    Object? identifier = null,
    Object? identifierType = null,
    Object? purpose = null,
    Object? code = null,
    Object? expiresAt = null,
  }) {
    return _then(_value.copyWith(
      identifier: null == identifier
          ? _value.identifier
          : identifier // ignore: cast_nullable_to_non_nullable
              as String,
      identifierType: null == identifierType
          ? _value.identifierType
          : identifierType // ignore: cast_nullable_to_non_nullable
              as String,
      purpose: null == purpose
          ? _value.purpose
          : purpose // ignore: cast_nullable_to_non_nullable
              as String,
      code: null == code
          ? _value.code
          : code // ignore: cast_nullable_to_non_nullable
              as String,
      expiresAt: null == expiresAt
          ? _value.expiresAt
          : expiresAt // ignore: cast_nullable_to_non_nullable
              as DateTime,
    ) as $Val);
  }
}

/// @nodoc
abstract class _$$OtpSessionModelImplCopyWith<$Res>
    implements $OtpSessionModelCopyWith<$Res> {
  factory _$$OtpSessionModelImplCopyWith(_$OtpSessionModelImpl value,
          $Res Function(_$OtpSessionModelImpl) then) =
      __$$OtpSessionModelImplCopyWithImpl<$Res>;
  @override
  @useResult
  $Res call(
      {String identifier,
      String identifierType,
      String purpose,
      String code,
      DateTime expiresAt});
}

/// @nodoc
class __$$OtpSessionModelImplCopyWithImpl<$Res>
    extends _$OtpSessionModelCopyWithImpl<$Res, _$OtpSessionModelImpl>
    implements _$$OtpSessionModelImplCopyWith<$Res> {
  __$$OtpSessionModelImplCopyWithImpl(
      _$OtpSessionModelImpl _value, $Res Function(_$OtpSessionModelImpl) _then)
      : super(_value, _then);

  @pragma('vm:prefer-inline')
  @override
  $Res call({
    Object? identifier = null,
    Object? identifierType = null,
    Object? purpose = null,
    Object? code = null,
    Object? expiresAt = null,
  }) {
    return _then(_$OtpSessionModelImpl(
      identifier: null == identifier
          ? _value.identifier
          : identifier // ignore: cast_nullable_to_non_nullable
              as String,
      identifierType: null == identifierType
          ? _value.identifierType
          : identifierType // ignore: cast_nullable_to_non_nullable
              as String,
      purpose: null == purpose
          ? _value.purpose
          : purpose // ignore: cast_nullable_to_non_nullable
              as String,
      code: null == code
          ? _value.code
          : code // ignore: cast_nullable_to_non_nullable
              as String,
      expiresAt: null == expiresAt
          ? _value.expiresAt
          : expiresAt // ignore: cast_nullable_to_non_nullable
              as DateTime,
    ));
  }
}

/// @nodoc
@JsonSerializable()
class _$OtpSessionModelImpl extends _OtpSessionModel {
  const _$OtpSessionModelImpl(
      {required this.identifier,
      required this.identifierType,
      required this.purpose,
      required this.code,
      required this.expiresAt})
      : super._();

  factory _$OtpSessionModelImpl.fromJson(Map<String, dynamic> json) =>
      _$$OtpSessionModelImplFromJson(json);

  @override
  final String identifier;
  @override
  final String identifierType;
// 'email' | 'phone'
  @override
  final String purpose;
// 'login' | 'signup'
  @override
  final String code;
  @override
  final DateTime expiresAt;

  @override
  String toString() {
    return 'OtpSessionModel(identifier: $identifier, identifierType: $identifierType, purpose: $purpose, code: $code, expiresAt: $expiresAt)';
  }

  @override
  bool operator ==(Object other) {
    return identical(this, other) ||
        (other.runtimeType == runtimeType &&
            other is _$OtpSessionModelImpl &&
            (identical(other.identifier, identifier) ||
                other.identifier == identifier) &&
            (identical(other.identifierType, identifierType) ||
                other.identifierType == identifierType) &&
            (identical(other.purpose, purpose) || other.purpose == purpose) &&
            (identical(other.code, code) || other.code == code) &&
            (identical(other.expiresAt, expiresAt) ||
                other.expiresAt == expiresAt));
  }

  @JsonKey(ignore: true)
  @override
  int get hashCode => Object.hash(
      runtimeType, identifier, identifierType, purpose, code, expiresAt);

  @JsonKey(ignore: true)
  @override
  @pragma('vm:prefer-inline')
  _$$OtpSessionModelImplCopyWith<_$OtpSessionModelImpl> get copyWith =>
      __$$OtpSessionModelImplCopyWithImpl<_$OtpSessionModelImpl>(
          this, _$identity);

  @override
  Map<String, dynamic> toJson() {
    return _$$OtpSessionModelImplToJson(
      this,
    );
  }
}

abstract class _OtpSessionModel extends OtpSessionModel {
  const factory _OtpSessionModel(
      {required final String identifier,
      required final String identifierType,
      required final String purpose,
      required final String code,
      required final DateTime expiresAt}) = _$OtpSessionModelImpl;
  const _OtpSessionModel._() : super._();

  factory _OtpSessionModel.fromJson(Map<String, dynamic> json) =
      _$OtpSessionModelImpl.fromJson;

  @override
  String get identifier;
  @override
  String get identifierType;
  @override // 'email' | 'phone'
  String get purpose;
  @override // 'login' | 'signup'
  String get code;
  @override
  DateTime get expiresAt;
  @override
  @JsonKey(ignore: true)
  _$$OtpSessionModelImplCopyWith<_$OtpSessionModelImpl> get copyWith =>
      throw _privateConstructorUsedError;
}
