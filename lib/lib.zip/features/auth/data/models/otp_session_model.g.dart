// GENERATED CODE - DO NOT MODIFY BY HAND

part of 'otp_session_model.dart';

// **************************************************************************
// JsonSerializableGenerator
// **************************************************************************

_$OtpSessionModelImpl _$$OtpSessionModelImplFromJson(
        Map<String, dynamic> json) =>
    _$OtpSessionModelImpl(
      identifier: json['identifier'] as String,
      identifierType: json['identifierType'] as String,
      purpose: json['purpose'] as String,
      code: json['code'] as String,
      expiresAt: DateTime.parse(json['expiresAt'] as String),
    );

Map<String, dynamic> _$$OtpSessionModelImplToJson(
        _$OtpSessionModelImpl instance) =>
    <String, dynamic>{
      'identifier': instance.identifier,
      'identifierType': instance.identifierType,
      'purpose': instance.purpose,
      'code': instance.code,
      'expiresAt': instance.expiresAt.toIso8601String(),
    };
