// GENERATED CODE - DO NOT MODIFY BY HAND

part of 'property_model.dart';

// **************************************************************************
// JsonSerializableGenerator
// **************************************************************************

_$PropertyModelImpl _$$PropertyModelImplFromJson(Map<String, dynamic> json) =>
    _$PropertyModelImpl(
      id: json['id'] as String,
      suite: json['suite'] as String? ?? '',
      floor: json['floor'] as String?,
      type: json['type'] as String?,
      building: json['building'] as String?,
    );

Map<String, dynamic> _$$PropertyModelImplToJson(_$PropertyModelImpl instance) =>
    <String, dynamic>{
      'id': instance.id,
      'suite': instance.suite,
      'floor': instance.floor,
      'type': instance.type,
      'building': instance.building,
    };
