// GENERATED CODE - DO NOT MODIFY BY HAND

part of 'family_member_model.dart';

// **************************************************************************
// JsonSerializableGenerator
// **************************************************************************

_$FamilyMemberModelImpl _$$FamilyMemberModelImplFromJson(
        Map<String, dynamic> json) =>
    _$FamilyMemberModelImpl(
      id: json['id'] as String,
      name: json['name'] as String? ?? '',
      email: json['email'] as String? ?? '',
      phone: json['phone'] as String? ?? '',
      relationship: json['relationship'] as String?,
      birthYear: (json['birthYear'] as num?)?.toInt(),
      gender: json['gender'] as String?,
    );

Map<String, dynamic> _$$FamilyMemberModelImplToJson(
        _$FamilyMemberModelImpl instance) =>
    <String, dynamic>{
      'id': instance.id,
      'name': instance.name,
      'email': instance.email,
      'phone': instance.phone,
      'relationship': instance.relationship,
      'birthYear': instance.birthYear,
      'gender': instance.gender,
    };
