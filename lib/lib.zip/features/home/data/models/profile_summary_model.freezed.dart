// coverage:ignore-file
// GENERATED CODE - DO NOT MODIFY BY HAND
// ignore_for_file: type=lint
// ignore_for_file: unused_element, deprecated_member_use, deprecated_member_use_from_same_package, use_function_type_syntax_for_parameters, unnecessary_const, avoid_init_to_null, invalid_override_different_default_values_named, prefer_expression_function_bodies, annotate_overrides, invalid_annotation_target, unnecessary_question_mark

part of 'profile_summary_model.dart';

// **************************************************************************
// FreezedGenerator
// **************************************************************************

T _$identity<T>(T value) => value;

final _privateConstructorUsedError = UnsupportedError(
    'It seems like you constructed your class using `MyClass._()`. This constructor is only meant to be used by freezed and you are not supposed to need it nor use it.\nPlease check the documentation here for more information: https://github.com/rrousselGit/freezed#adding-getters-and-methods-to-our-models');

ProfileSummaryModel _$ProfileSummaryModelFromJson(Map<String, dynamic> json) {
  return _ProfileSummaryModel.fromJson(json);
}

/// @nodoc
mixin _$ProfileSummaryModel {
  String get name => throw _privateConstructorUsedError;
  String get email => throw _privateConstructorUsedError;
  String get phone => throw _privateConstructorUsedError;
  String? get avatarUrl => throw _privateConstructorUsedError;

  Map<String, dynamic> toJson() => throw _privateConstructorUsedError;
  @JsonKey(ignore: true)
  $ProfileSummaryModelCopyWith<ProfileSummaryModel> get copyWith =>
      throw _privateConstructorUsedError;
}

/// @nodoc
abstract class $ProfileSummaryModelCopyWith<$Res> {
  factory $ProfileSummaryModelCopyWith(
          ProfileSummaryModel value, $Res Function(ProfileSummaryModel) then) =
      _$ProfileSummaryModelCopyWithImpl<$Res, ProfileSummaryModel>;
  @useResult
  $Res call({String name, String email, String phone, String? avatarUrl});
}

/// @nodoc
class _$ProfileSummaryModelCopyWithImpl<$Res, $Val extends ProfileSummaryModel>
    implements $ProfileSummaryModelCopyWith<$Res> {
  _$ProfileSummaryModelCopyWithImpl(this._value, this._then);

  // ignore: unused_field
  final $Val _value;
  // ignore: unused_field
  final $Res Function($Val) _then;

  @pragma('vm:prefer-inline')
  @override
  $Res call({
    Object? name = null,
    Object? email = null,
    Object? phone = null,
    Object? avatarUrl = freezed,
  }) {
    return _then(_value.copyWith(
      name: null == name
          ? _value.name
          : name // ignore: cast_nullable_to_non_nullable
              as String,
      email: null == email
          ? _value.email
          : email // ignore: cast_nullable_to_non_nullable
              as String,
      phone: null == phone
          ? _value.phone
          : phone // ignore: cast_nullable_to_non_nullable
              as String,
      avatarUrl: freezed == avatarUrl
          ? _value.avatarUrl
          : avatarUrl // ignore: cast_nullable_to_non_nullable
              as String?,
    ) as $Val);
  }
}

/// @nodoc
abstract class _$$ProfileSummaryModelImplCopyWith<$Res>
    implements $ProfileSummaryModelCopyWith<$Res> {
  factory _$$ProfileSummaryModelImplCopyWith(_$ProfileSummaryModelImpl value,
          $Res Function(_$ProfileSummaryModelImpl) then) =
      __$$ProfileSummaryModelImplCopyWithImpl<$Res>;
  @override
  @useResult
  $Res call({String name, String email, String phone, String? avatarUrl});
}

/// @nodoc
class __$$ProfileSummaryModelImplCopyWithImpl<$Res>
    extends _$ProfileSummaryModelCopyWithImpl<$Res, _$ProfileSummaryModelImpl>
    implements _$$ProfileSummaryModelImplCopyWith<$Res> {
  __$$ProfileSummaryModelImplCopyWithImpl(_$ProfileSummaryModelImpl _value,
      $Res Function(_$ProfileSummaryModelImpl) _then)
      : super(_value, _then);

  @pragma('vm:prefer-inline')
  @override
  $Res call({
    Object? name = null,
    Object? email = null,
    Object? phone = null,
    Object? avatarUrl = freezed,
  }) {
    return _then(_$ProfileSummaryModelImpl(
      name: null == name
          ? _value.name
          : name // ignore: cast_nullable_to_non_nullable
              as String,
      email: null == email
          ? _value.email
          : email // ignore: cast_nullable_to_non_nullable
              as String,
      phone: null == phone
          ? _value.phone
          : phone // ignore: cast_nullable_to_non_nullable
              as String,
      avatarUrl: freezed == avatarUrl
          ? _value.avatarUrl
          : avatarUrl // ignore: cast_nullable_to_non_nullable
              as String?,
    ));
  }
}

/// @nodoc
@JsonSerializable()
class _$ProfileSummaryModelImpl extends _ProfileSummaryModel {
  const _$ProfileSummaryModelImpl(
      {required this.name,
      required this.email,
      required this.phone,
      this.avatarUrl})
      : super._();

  factory _$ProfileSummaryModelImpl.fromJson(Map<String, dynamic> json) =>
      _$$ProfileSummaryModelImplFromJson(json);

  @override
  final String name;
  @override
  final String email;
  @override
  final String phone;
  @override
  final String? avatarUrl;

  @override
  String toString() {
    return 'ProfileSummaryModel(name: $name, email: $email, phone: $phone, avatarUrl: $avatarUrl)';
  }

  @override
  bool operator ==(Object other) {
    return identical(this, other) ||
        (other.runtimeType == runtimeType &&
            other is _$ProfileSummaryModelImpl &&
            (identical(other.name, name) || other.name == name) &&
            (identical(other.email, email) || other.email == email) &&
            (identical(other.phone, phone) || other.phone == phone) &&
            (identical(other.avatarUrl, avatarUrl) ||
                other.avatarUrl == avatarUrl));
  }

  @JsonKey(ignore: true)
  @override
  int get hashCode => Object.hash(runtimeType, name, email, phone, avatarUrl);

  @JsonKey(ignore: true)
  @override
  @pragma('vm:prefer-inline')
  _$$ProfileSummaryModelImplCopyWith<_$ProfileSummaryModelImpl> get copyWith =>
      __$$ProfileSummaryModelImplCopyWithImpl<_$ProfileSummaryModelImpl>(
          this, _$identity);

  @override
  Map<String, dynamic> toJson() {
    return _$$ProfileSummaryModelImplToJson(
      this,
    );
  }
}

abstract class _ProfileSummaryModel extends ProfileSummaryModel {
  const factory _ProfileSummaryModel(
      {required final String name,
      required final String email,
      required final String phone,
      final String? avatarUrl}) = _$ProfileSummaryModelImpl;
  const _ProfileSummaryModel._() : super._();

  factory _ProfileSummaryModel.fromJson(Map<String, dynamic> json) =
      _$ProfileSummaryModelImpl.fromJson;

  @override
  String get name;
  @override
  String get email;
  @override
  String get phone;
  @override
  String? get avatarUrl;
  @override
  @JsonKey(ignore: true)
  _$$ProfileSummaryModelImplCopyWith<_$ProfileSummaryModelImpl> get copyWith =>
      throw _privateConstructorUsedError;
}
