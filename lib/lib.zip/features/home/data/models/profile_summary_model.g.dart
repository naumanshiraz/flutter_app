// GENERATED CODE - DO NOT MODIFY BY HAND

part of 'profile_summary_model.dart';

// **************************************************************************
// JsonSerializableGenerator
// **************************************************************************

_$ProfileSummaryModelImpl _$$ProfileSummaryModelImplFromJson(
        Map<String, dynamic> json) =>
    _$ProfileSummaryModelImpl(
      name: json['name'] as String,
      email: json['email'] as String,
      phone: json['phone'] as String,
      avatarUrl: json['avatarUrl'] as String?,
    );

Map<String, dynamic> _$$ProfileSummaryModelImplToJson(
        _$ProfileSummaryModelImpl instance) =>
    <String, dynamic>{
      'name': instance.name,
      'email': instance.email,
      'phone': instance.phone,
      'avatarUrl': instance.avatarUrl,
    };
