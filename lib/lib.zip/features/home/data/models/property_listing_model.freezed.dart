// coverage:ignore-file
// GENERATED CODE - DO NOT MODIFY BY HAND
// ignore_for_file: type=lint
// ignore_for_file: unused_element, deprecated_member_use, deprecated_member_use_from_same_package, use_function_type_syntax_for_parameters, unnecessary_const, avoid_init_to_null, invalid_override_different_default_values_named, prefer_expression_function_bodies, annotate_overrides, invalid_annotation_target, unnecessary_question_mark

part of 'property_listing_model.dart';

// **************************************************************************
// FreezedGenerator
// **************************************************************************

T _$identity<T>(T value) => value;

final _privateConstructorUsedError = UnsupportedError(
    'It seems like you constructed your class using `MyClass._()`. This constructor is only meant to be used by freezed and you are not supposed to need it nor use it.\nPlease check the documentation here for more information: https://github.com/rrousselGit/freezed#adding-getters-and-methods-to-our-models');

PropertyListingModel _$PropertyListingModelFromJson(Map<String, dynamic> json) {
  return _PropertyListingModel.fromJson(json);
}

/// @nodoc
mixin _$PropertyListingModel {
  String get id => throw _privateConstructorUsedError;
  String get title => throw _privateConstructorUsedError;
  String get managementCompany => throw _privateConstructorUsedError;
  String get imageUrl => throw _privateConstructorUsedError;

  Map<String, dynamic> toJson() => throw _privateConstructorUsedError;
  @JsonKey(ignore: true)
  $PropertyListingModelCopyWith<PropertyListingModel> get copyWith =>
      throw _privateConstructorUsedError;
}

/// @nodoc
abstract class $PropertyListingModelCopyWith<$Res> {
  factory $PropertyListingModelCopyWith(PropertyListingModel value,
          $Res Function(PropertyListingModel) then) =
      _$PropertyListingModelCopyWithImpl<$Res, PropertyListingModel>;
  @useResult
  $Res call(
      {String id, String title, String managementCompany, String imageUrl});
}

/// @nodoc
class _$PropertyListingModelCopyWithImpl<$Res,
        $Val extends PropertyListingModel>
    implements $PropertyListingModelCopyWith<$Res> {
  _$PropertyListingModelCopyWithImpl(this._value, this._then);

  // ignore: unused_field
  final $Val _value;
  // ignore: unused_field
  final $Res Function($Val) _then;

  @pragma('vm:prefer-inline')
  @override
  $Res call({
    Object? id = null,
    Object? title = null,
    Object? managementCompany = null,
    Object? imageUrl = null,
  }) {
    return _then(_value.copyWith(
      id: null == id
          ? _value.id
          : id // ignore: cast_nullable_to_non_nullable
              as String,
      title: null == title
          ? _value.title
          : title // ignore: cast_nullable_to_non_nullable
              as String,
      managementCompany: null == managementCompany
          ? _value.managementCompany
          : managementCompany // ignore: cast_nullable_to_non_nullable
              as String,
      imageUrl: null == imageUrl
          ? _value.imageUrl
          : imageUrl // ignore: cast_nullable_to_non_nullable
              as String,
    ) as $Val);
  }
}

/// @nodoc
abstract class _$$PropertyListingModelImplCopyWith<$Res>
    implements $PropertyListingModelCopyWith<$Res> {
  factory _$$PropertyListingModelImplCopyWith(_$PropertyListingModelImpl value,
          $Res Function(_$PropertyListingModelImpl) then) =
      __$$PropertyListingModelImplCopyWithImpl<$Res>;
  @override
  @useResult
  $Res call(
      {String id, String title, String managementCompany, String imageUrl});
}

/// @nodoc
class __$$PropertyListingModelImplCopyWithImpl<$Res>
    extends _$PropertyListingModelCopyWithImpl<$Res, _$PropertyListingModelImpl>
    implements _$$PropertyListingModelImplCopyWith<$Res> {
  __$$PropertyListingModelImplCopyWithImpl(_$PropertyListingModelImpl _value,
      $Res Function(_$PropertyListingModelImpl) _then)
      : super(_value, _then);

  @pragma('vm:prefer-inline')
  @override
  $Res call({
    Object? id = null,
    Object? title = null,
    Object? managementCompany = null,
    Object? imageUrl = null,
  }) {
    return _then(_$PropertyListingModelImpl(
      id: null == id
          ? _value.id
          : id // ignore: cast_nullable_to_non_nullable
              as String,
      title: null == title
          ? _value.title
          : title // ignore: cast_nullable_to_non_nullable
              as String,
      managementCompany: null == managementCompany
          ? _value.managementCompany
          : managementCompany // ignore: cast_nullable_to_non_nullable
              as String,
      imageUrl: null == imageUrl
          ? _value.imageUrl
          : imageUrl // ignore: cast_nullable_to_non_nullable
              as String,
    ));
  }
}

/// @nodoc
@JsonSerializable()
class _$PropertyListingModelImpl extends _PropertyListingModel {
  const _$PropertyListingModelImpl(
      {required this.id,
      required this.title,
      required this.managementCompany,
      required this.imageUrl})
      : super._();

  factory _$PropertyListingModelImpl.fromJson(Map<String, dynamic> json) =>
      _$$PropertyListingModelImplFromJson(json);

  @override
  final String id;
  @override
  final String title;
  @override
  final String managementCompany;
  @override
  final String imageUrl;

  @override
  String toString() {
    return 'PropertyListingModel(id: $id, title: $title, managementCompany: $managementCompany, imageUrl: $imageUrl)';
  }

  @override
  bool operator ==(Object other) {
    return identical(this, other) ||
        (other.runtimeType == runtimeType &&
            other is _$PropertyListingModelImpl &&
            (identical(other.id, id) || other.id == id) &&
            (identical(other.title, title) || other.title == title) &&
            (identical(other.managementCompany, managementCompany) ||
                other.managementCompany == managementCompany) &&
            (identical(other.imageUrl, imageUrl) ||
                other.imageUrl == imageUrl));
  }

  @JsonKey(ignore: true)
  @override
  int get hashCode =>
      Object.hash(runtimeType, id, title, managementCompany, imageUrl);

  @JsonKey(ignore: true)
  @override
  @pragma('vm:prefer-inline')
  _$$PropertyListingModelImplCopyWith<_$PropertyListingModelImpl>
      get copyWith =>
          __$$PropertyListingModelImplCopyWithImpl<_$PropertyListingModelImpl>(
              this, _$identity);

  @override
  Map<String, dynamic> toJson() {
    return _$$PropertyListingModelImplToJson(
      this,
    );
  }
}

abstract class _PropertyListingModel extends PropertyListingModel {
  const factory _PropertyListingModel(
      {required final String id,
      required final String title,
      required final String managementCompany,
      required final String imageUrl}) = _$PropertyListingModelImpl;
  const _PropertyListingModel._() : super._();

  factory _PropertyListingModel.fromJson(Map<String, dynamic> json) =
      _$PropertyListingModelImpl.fromJson;

  @override
  String get id;
  @override
  String get title;
  @override
  String get managementCompany;
  @override
  String get imageUrl;
  @override
  @JsonKey(ignore: true)
  _$$PropertyListingModelImplCopyWith<_$PropertyListingModelImpl>
      get copyWith => throw _privateConstructorUsedError;
}
