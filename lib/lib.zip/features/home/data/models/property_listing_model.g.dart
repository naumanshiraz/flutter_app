// GENERATED CODE - DO NOT MODIFY BY HAND

part of 'property_listing_model.dart';

// **************************************************************************
// JsonSerializableGenerator
// **************************************************************************

_$PropertyListingModelImpl _$$PropertyListingModelImplFromJson(
        Map<String, dynamic> json) =>
    _$PropertyListingModelImpl(
      id: json['id'] as String,
      title: json['title'] as String,
      managementCompany: json['managementCompany'] as String,
      imageUrl: json['imageUrl'] as String,
    );

Map<String, dynamic> _$$PropertyListingModelImplToJson(
        _$PropertyListingModelImpl instance) =>
    <String, dynamic>{
      'id': instance.id,
      'title': instance.title,
      'managementCompany': instance.managementCompany,
      'imageUrl': instance.imageUrl,
    };
