// GENERATED CODE - DO NOT MODIFY BY HAND

part of 'pet_model.dart';

// **************************************************************************
// JsonSerializableGenerator
// **************************************************************************

_$PetModelImpl _$$PetModelImplFromJson(Map<String, dynamic> json) =>
    _$PetModelImpl(
      id: json['id'] as String,
      species: json['species'] as String?,
      breed: json['breed'] as String? ?? '',
      numberOfPets: json['numberOfPets'] as String? ?? '',
    );

Map<String, dynamic> _$$PetModelImplToJson(_$PetModelImpl instance) =>
    <String, dynamic>{
      'id': instance.id,
      'species': instance.species,
      'breed': instance.breed,
      'numberOfPets': instance.numberOfPets,
    };
