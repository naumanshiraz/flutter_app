// GENERATED CODE - DO NOT MODIFY BY HAND

part of 'residency_address_model.dart';

// **************************************************************************
// JsonSerializableGenerator
// **************************************************************************

_$ResidencyAddressModelImpl _$$ResidencyAddressModelImplFromJson(
        Map<String, dynamic> json) =>
    _$ResidencyAddressModelImpl(
      country: json['country'] as String?,
      city: json['city'] as String?,
      district: json['district'] as String?,
      khoroo: json['khoroo'] as String?,
      residence: json['residence'] as String?,
    );

Map<String, dynamic> _$$ResidencyAddressModelImplToJson(
        _$ResidencyAddressModelImpl instance) =>
    <String, dynamic>{
      'country': instance.country,
      'city': instance.city,
      'district': instance.district,
      'khoroo': instance.khoroo,
      'residence': instance.residence,
    };
