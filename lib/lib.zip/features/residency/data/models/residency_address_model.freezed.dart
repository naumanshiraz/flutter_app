// coverage:ignore-file
// GENERATED CODE - DO NOT MODIFY BY HAND
// ignore_for_file: type=lint
// ignore_for_file: unused_element, deprecated_member_use, deprecated_member_use_from_same_package, use_function_type_syntax_for_parameters, unnecessary_const, avoid_init_to_null, invalid_override_different_default_values_named, prefer_expression_function_bodies, annotate_overrides, invalid_annotation_target, unnecessary_question_mark

part of 'residency_address_model.dart';

// **************************************************************************
// FreezedGenerator
// **************************************************************************

T _$identity<T>(T value) => value;

final _privateConstructorUsedError = UnsupportedError(
    'It seems like you constructed your class using `MyClass._()`. This constructor is only meant to be used by freezed and you are not supposed to need it nor use it.\nPlease check the documentation here for more information: https://github.com/rrousselGit/freezed#adding-getters-and-methods-to-our-models');

ResidencyAddressModel _$ResidencyAddressModelFromJson(
    Map<String, dynamic> json) {
  return _ResidencyAddressModel.fromJson(json);
}

/// @nodoc
mixin _$ResidencyAddressModel {
  String? get country => throw _privateConstructorUsedError;
  String? get city => throw _privateConstructorUsedError;
  String? get district => throw _privateConstructorUsedError;
  String? get khoroo => throw _privateConstructorUsedError;
  String? get residence => throw _privateConstructorUsedError;

  Map<String, dynamic> toJson() => throw _privateConstructorUsedError;
  @JsonKey(ignore: true)
  $ResidencyAddressModelCopyWith<ResidencyAddressModel> get copyWith =>
      throw _privateConstructorUsedError;
}

/// @nodoc
abstract class $ResidencyAddressModelCopyWith<$Res> {
  factory $ResidencyAddressModelCopyWith(ResidencyAddressModel value,
          $Res Function(ResidencyAddressModel) then) =
      _$ResidencyAddressModelCopyWithImpl<$Res, ResidencyAddressModel>;
  @useResult
  $Res call(
      {String? country,
      String? city,
      String? district,
      String? khoroo,
      String? residence});
}

/// @nodoc
class _$ResidencyAddressModelCopyWithImpl<$Res,
        $Val extends ResidencyAddressModel>
    implements $ResidencyAddressModelCopyWith<$Res> {
  _$ResidencyAddressModelCopyWithImpl(this._value, this._then);

  // ignore: unused_field
  final $Val _value;
  // ignore: unused_field
  final $Res Function($Val) _then;

  @pragma('vm:prefer-inline')
  @override
  $Res call({
    Object? country = freezed,
    Object? city = freezed,
    Object? district = freezed,
    Object? khoroo = freezed,
    Object? residence = freezed,
  }) {
    return _then(_value.copyWith(
      country: freezed == country
          ? _value.country
          : country // ignore: cast_nullable_to_non_nullable
              as String?,
      city: freezed == city
          ? _value.city
          : city // ignore: cast_nullable_to_non_nullable
              as String?,
      district: freezed == district
          ? _value.district
          : district // ignore: cast_nullable_to_non_nullable
              as String?,
      khoroo: freezed == khoroo
          ? _value.khoroo
          : khoroo // ignore: cast_nullable_to_non_nullable
              as String?,
      residence: freezed == residence
          ? _value.residence
          : residence // ignore: cast_nullable_to_non_nullable
              as String?,
    ) as $Val);
  }
}

/// @nodoc
abstract class _$$ResidencyAddressModelImplCopyWith<$Res>
    implements $ResidencyAddressModelCopyWith<$Res> {
  factory _$$ResidencyAddressModelImplCopyWith(
          _$ResidencyAddressModelImpl value,
          $Res Function(_$ResidencyAddressModelImpl) then) =
      __$$ResidencyAddressModelImplCopyWithImpl<$Res>;
  @override
  @useResult
  $Res call(
      {String? country,
      String? city,
      String? district,
      String? khoroo,
      String? residence});
}

/// @nodoc
class __$$ResidencyAddressModelImplCopyWithImpl<$Res>
    extends _$ResidencyAddressModelCopyWithImpl<$Res,
        _$ResidencyAddressModelImpl>
    implements _$$ResidencyAddressModelImplCopyWith<$Res> {
  __$$ResidencyAddressModelImplCopyWithImpl(_$ResidencyAddressModelImpl _value,
      $Res Function(_$ResidencyAddressModelImpl) _then)
      : super(_value, _then);

  @pragma('vm:prefer-inline')
  @override
  $Res call({
    Object? country = freezed,
    Object? city = freezed,
    Object? district = freezed,
    Object? khoroo = freezed,
    Object? residence = freezed,
  }) {
    return _then(_$ResidencyAddressModelImpl(
      country: freezed == country
          ? _value.country
          : country // ignore: cast_nullable_to_non_nullable
              as String?,
      city: freezed == city
          ? _value.city
          : city // ignore: cast_nullable_to_non_nullable
              as String?,
      district: freezed == district
          ? _value.district
          : district // ignore: cast_nullable_to_non_nullable
              as String?,
      khoroo: freezed == khoroo
          ? _value.khoroo
          : khoroo // ignore: cast_nullable_to_non_nullable
              as String?,
      residence: freezed == residence
          ? _value.residence
          : residence // ignore: cast_nullable_to_non_nullable
              as String?,
    ));
  }
}

/// @nodoc
@JsonSerializable()
class _$ResidencyAddressModelImpl extends _ResidencyAddressModel {
  const _$ResidencyAddressModelImpl(
      {this.country, this.city, this.district, this.khoroo, this.residence})
      : super._();

  factory _$ResidencyAddressModelImpl.fromJson(Map<String, dynamic> json) =>
      _$$ResidencyAddressModelImplFromJson(json);

  @override
  final String? country;
  @override
  final String? city;
  @override
  final String? district;
  @override
  final String? khoroo;
  @override
  final String? residence;

  @override
  String toString() {
    return 'ResidencyAddressModel(country: $country, city: $city, district: $district, khoroo: $khoroo, residence: $residence)';
  }

  @override
  bool operator ==(Object other) {
    return identical(this, other) ||
        (other.runtimeType == runtimeType &&
            other is _$ResidencyAddressModelImpl &&
            (identical(other.country, country) || other.country == country) &&
            (identical(other.city, city) || other.city == city) &&
            (identical(other.district, district) ||
                other.district == district) &&
            (identical(other.khoroo, khoroo) || other.khoroo == khoroo) &&
            (identical(other.residence, residence) ||
                other.residence == residence));
  }

  @JsonKey(ignore: true)
  @override
  int get hashCode =>
      Object.hash(runtimeType, country, city, district, khoroo, residence);

  @JsonKey(ignore: true)
  @override
  @pragma('vm:prefer-inline')
  _$$ResidencyAddressModelImplCopyWith<_$ResidencyAddressModelImpl>
      get copyWith => __$$ResidencyAddressModelImplCopyWithImpl<
          _$ResidencyAddressModelImpl>(this, _$identity);

  @override
  Map<String, dynamic> toJson() {
    return _$$ResidencyAddressModelImplToJson(
      this,
    );
  }
}

abstract class _ResidencyAddressModel extends ResidencyAddressModel {
  const factory _ResidencyAddressModel(
      {final String? country,
      final String? city,
      final String? district,
      final String? khoroo,
      final String? residence}) = _$ResidencyAddressModelImpl;
  const _ResidencyAddressModel._() : super._();

  factory _ResidencyAddressModel.fromJson(Map<String, dynamic> json) =
      _$ResidencyAddressModelImpl.fromJson;

  @override
  String? get country;
  @override
  String? get city;
  @override
  String? get district;
  @override
  String? get khoroo;
  @override
  String? get residence;
  @override
  @JsonKey(ignore: true)
  _$$ResidencyAddressModelImplCopyWith<_$ResidencyAddressModelImpl>
      get copyWith => throw _privateConstructorUsedError;
}
