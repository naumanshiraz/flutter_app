// coverage:ignore-file
// GENERATED CODE - DO NOT MODIFY BY HAND
// ignore_for_file: type=lint
// ignore_for_file: unused_element, deprecated_member_use, deprecated_member_use_from_same_package, use_function_type_syntax_for_parameters, unnecessary_const, avoid_init_to_null, invalid_override_different_default_values_named, prefer_expression_function_bodies, annotate_overrides, invalid_annotation_target, unnecessary_question_mark

part of 'editable_profile_model.dart';

// **************************************************************************
// FreezedGenerator
// **************************************************************************

T _$identity<T>(T value) => value;

final _privateConstructorUsedError = UnsupportedError(
    'It seems like you constructed your class using `MyClass._()`. This constructor is only meant to be used by freezed and you are not supposed to need it nor use it.\nPlease check the documentation here for more information: https://github.com/rrousselGit/freezed#adding-getters-and-methods-to-our-models');

EditableProfileModel _$EditableProfileModelFromJson(Map<String, dynamic> json) {
  return _EditableProfileModel.fromJson(json);
}

/// @nodoc
mixin _$EditableProfileModel {
  String get name => throw _privateConstructorUsedError;
  String get email => throw _privateConstructorUsedError;
  String get phone => throw _privateConstructorUsedError;
  String? get country => throw _privateConstructorUsedError;
  DateTime? get birthDate => throw _privateConstructorUsedError;
  String? get pronouns => throw _privateConstructorUsedError;
  String? get avatarPath => throw _privateConstructorUsedError;

  Map<String, dynamic> toJson() => throw _privateConstructorUsedError;
  @JsonKey(ignore: true)
  $EditableProfileModelCopyWith<EditableProfileModel> get copyWith =>
      throw _privateConstructorUsedError;
}

/// @nodoc
abstract class $EditableProfileModelCopyWith<$Res> {
  factory $EditableProfileModelCopyWith(EditableProfileModel value,
          $Res Function(EditableProfileModel) then) =
      _$EditableProfileModelCopyWithImpl<$Res, EditableProfileModel>;
  @useResult
  $Res call(
      {String name,
      String email,
      String phone,
      String? country,
      DateTime? birthDate,
      String? pronouns,
      String? avatarPath});
}

/// @nodoc
class _$EditableProfileModelCopyWithImpl<$Res,
        $Val extends EditableProfileModel>
    implements $EditableProfileModelCopyWith<$Res> {
  _$EditableProfileModelCopyWithImpl(this._value, this._then);

  // ignore: unused_field
  final $Val _value;
  // ignore: unused_field
  final $Res Function($Val) _then;

  @pragma('vm:prefer-inline')
  @override
  $Res call({
    Object? name = null,
    Object? email = null,
    Object? phone = null,
    Object? country = freezed,
    Object? birthDate = freezed,
    Object? pronouns = freezed,
    Object? avatarPath = freezed,
  }) {
    return _then(_value.copyWith(
      name: null == name
          ? _value.name
          : name // ignore: cast_nullable_to_non_nullable
              as String,
      email: null == email
          ? _value.email
          : email // ignore: cast_nullable_to_non_nullable
              as String,
      phone: null == phone
          ? _value.phone
          : phone // ignore: cast_nullable_to_non_nullable
              as String,
      country: freezed == country
          ? _value.country
          : country // ignore: cast_nullable_to_non_nullable
              as String?,
      birthDate: freezed == birthDate
          ? _value.birthDate
          : birthDate // ignore: cast_nullable_to_non_nullable
              as DateTime?,
      pronouns: freezed == pronouns
          ? _value.pronouns
          : pronouns // ignore: cast_nullable_to_non_nullable
              as String?,
      avatarPath: freezed == avatarPath
          ? _value.avatarPath
          : avatarPath // ignore: cast_nullable_to_non_nullable
              as String?,
    ) as $Val);
  }
}

/// @nodoc
abstract class _$$EditableProfileModelImplCopyWith<$Res>
    implements $EditableProfileModelCopyWith<$Res> {
  factory _$$EditableProfileModelImplCopyWith(_$EditableProfileModelImpl value,
          $Res Function(_$EditableProfileModelImpl) then) =
      __$$EditableProfileModelImplCopyWithImpl<$Res>;
  @override
  @useResult
  $Res call(
      {String name,
      String email,
      String phone,
      String? country,
      DateTime? birthDate,
      String? pronouns,
      String? avatarPath});
}

/// @nodoc
class __$$EditableProfileModelImplCopyWithImpl<$Res>
    extends _$EditableProfileModelCopyWithImpl<$Res, _$EditableProfileModelImpl>
    implements _$$EditableProfileModelImplCopyWith<$Res> {
  __$$EditableProfileModelImplCopyWithImpl(_$EditableProfileModelImpl _value,
      $Res Function(_$EditableProfileModelImpl) _then)
      : super(_value, _then);

  @pragma('vm:prefer-inline')
  @override
  $Res call({
    Object? name = null,
    Object? email = null,
    Object? phone = null,
    Object? country = freezed,
    Object? birthDate = freezed,
    Object? pronouns = freezed,
    Object? avatarPath = freezed,
  }) {
    return _then(_$EditableProfileModelImpl(
      name: null == name
          ? _value.name
          : name // ignore: cast_nullable_to_non_nullable
              as String,
      email: null == email
          ? _value.email
          : email // ignore: cast_nullable_to_non_nullable
              as String,
      phone: null == phone
          ? _value.phone
          : phone // ignore: cast_nullable_to_non_nullable
              as String,
      country: freezed == country
          ? _value.country
          : country // ignore: cast_nullable_to_non_nullable
              as String?,
      birthDate: freezed == birthDate
          ? _value.birthDate
          : birthDate // ignore: cast_nullable_to_non_nullable
              as DateTime?,
      pronouns: freezed == pronouns
          ? _value.pronouns
          : pronouns // ignore: cast_nullable_to_non_nullable
              as String?,
      avatarPath: freezed == avatarPath
          ? _value.avatarPath
          : avatarPath // ignore: cast_nullable_to_non_nullable
              as String?,
    ));
  }
}

/// @nodoc
@JsonSerializable()
class _$EditableProfileModelImpl extends _EditableProfileModel {
  const _$EditableProfileModelImpl(
      {this.name = '',
      this.email = '',
      this.phone = '',
      this.country,
      this.birthDate,
      this.pronouns,
      this.avatarPath})
      : super._();

  factory _$EditableProfileModelImpl.fromJson(Map<String, dynamic> json) =>
      _$$EditableProfileModelImplFromJson(json);

  @override
  @JsonKey()
  final String name;
  @override
  @JsonKey()
  final String email;
  @override
  @JsonKey()
  final String phone;
  @override
  final String? country;
  @override
  final DateTime? birthDate;
  @override
  final String? pronouns;
  @override
  final String? avatarPath;

  @override
  String toString() {
    return 'EditableProfileModel(name: $name, email: $email, phone: $phone, country: $country, birthDate: $birthDate, pronouns: $pronouns, avatarPath: $avatarPath)';
  }

  @override
  bool operator ==(Object other) {
    return identical(this, other) ||
        (other.runtimeType == runtimeType &&
            other is _$EditableProfileModelImpl &&
            (identical(other.name, name) || other.name == name) &&
            (identical(other.email, email) || other.email == email) &&
            (identical(other.phone, phone) || other.phone == phone) &&
            (identical(other.country, country) || other.country == country) &&
            (identical(other.birthDate, birthDate) ||
                other.birthDate == birthDate) &&
            (identical(other.pronouns, pronouns) ||
                other.pronouns == pronouns) &&
            (identical(other.avatarPath, avatarPath) ||
                other.avatarPath == avatarPath));
  }

  @JsonKey(ignore: true)
  @override
  int get hashCode => Object.hash(runtimeType, name, email, phone, country,
      birthDate, pronouns, avatarPath);

  @JsonKey(ignore: true)
  @override
  @pragma('vm:prefer-inline')
  _$$EditableProfileModelImplCopyWith<_$EditableProfileModelImpl>
      get copyWith =>
          __$$EditableProfileModelImplCopyWithImpl<_$EditableProfileModelImpl>(
              this, _$identity);

  @override
  Map<String, dynamic> toJson() {
    return _$$EditableProfileModelImplToJson(
      this,
    );
  }
}

abstract class _EditableProfileModel extends EditableProfileModel {
  const factory _EditableProfileModel(
      {final String name,
      final String email,
      final String phone,
      final String? country,
      final DateTime? birthDate,
      final String? pronouns,
      final String? avatarPath}) = _$EditableProfileModelImpl;
  const _EditableProfileModel._() : super._();

  factory _EditableProfileModel.fromJson(Map<String, dynamic> json) =
      _$EditableProfileModelImpl.fromJson;

  @override
  String get name;
  @override
  String get email;
  @override
  String get phone;
  @override
  String? get country;
  @override
  DateTime? get birthDate;
  @override
  String? get pronouns;
  @override
  String? get avatarPath;
  @override
  @JsonKey(ignore: true)
  _$$EditableProfileModelImplCopyWith<_$EditableProfileModelImpl>
      get copyWith => throw _privateConstructorUsedError;
}
