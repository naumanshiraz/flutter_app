// GENERATED CODE - DO NOT MODIFY BY HAND

part of 'editable_profile_model.dart';

// **************************************************************************
// JsonSerializableGenerator
// **************************************************************************

_$EditableProfileModelImpl _$$EditableProfileModelImplFromJson(
        Map<String, dynamic> json) =>
    _$EditableProfileModelImpl(
      name: json['name'] as String? ?? '',
      email: json['email'] as String? ?? '',
      phone: json['phone'] as String? ?? '',
      country: json['country'] as String?,
      birthDate: json['birthDate'] == null
          ? null
          : DateTime.parse(json['birthDate'] as String),
      pronouns: json['pronouns'] as String?,
      avatarPath: json['avatarPath'] as String?,
    );

Map<String, dynamic> _$$EditableProfileModelImplToJson(
        _$EditableProfileModelImpl instance) =>
    <String, dynamic>{
      'name': instance.name,
      'email': instance.email,
      'phone': instance.phone,
      'country': instance.country,
      'birthDate': instance.birthDate?.toIso8601String(),
      'pronouns': instance.pronouns,
      'avatarPath': instance.avatarPath,
    };
